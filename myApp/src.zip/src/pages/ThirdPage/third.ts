import { Component } from '@angular/core';

import { NavController,NavParams} from 'ionic-angular';



@Component({
  selector: 'page-Third',
  templateUrl: 'ThirdPage.html'
})


export class Thirdpage {
	
}