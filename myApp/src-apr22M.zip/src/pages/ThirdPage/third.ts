import { Component } from '@angular/core';

import { NavController,NavParams,ViewController} from 'ionic-angular';



@Component({
  selector: 'page-Third',
  templateUrl: 'ThirdPage.html'
})


export class Thirdpage {
	 constructor(private nav:NavController,private viewCtrl:ViewController) {
		
    }
	closeMe(){
		this.viewCtrl.dismiss();
		}
}